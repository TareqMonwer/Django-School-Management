﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","gl",{title:"Recolledor de cor da interface de usuario",preview:"Vista previa en vivo",config:"Pegue esta cadea no seu ficheiro config.js",predefined:"Conxuntos predefinidos de cores"});